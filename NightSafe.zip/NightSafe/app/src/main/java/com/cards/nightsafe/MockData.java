package com.cards.nightsafe;

public class MockData {

    String[] emergencyContacts = new String[]{"Mum", "Dad"};
    String[] group = new String[]{"Adam", "Visva", "Matthew", "Hana", "Lucsz"};
}
