package com.cards.nightsafe;

import java.util.ArrayList;

public class GroupDestination {

  private ArrayList<String> usernames;
  private String destination;


  public GroupDestination(ArrayList<String> usernames, String destination) {
    this.usernames = usernames;
    this.destination = destination;
  }

}
